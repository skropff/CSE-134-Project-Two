# Project 2: MapReduce

See wiki for instructions: https://github.com/UCSC-CSE-134/project2-map-reduce/wiki/README

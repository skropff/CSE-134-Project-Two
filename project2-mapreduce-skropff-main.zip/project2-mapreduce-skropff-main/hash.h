#pragma once

unsigned long hash(char* str);
